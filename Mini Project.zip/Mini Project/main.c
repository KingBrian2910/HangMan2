#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include "Minilib.h"


int main()
{
    char a='a',z, word[100][100],spot[1000];
    int i=0,W=0,j=0, o=0,choice=0,ch,x=0, freq[26] = {0}, flag[26] = {0}, loc[1000][26]={0},c,f=0,score,count=0,ascore[3],highscore=0;
    srand(time(NULL));
    FILE *file;
    FILE *sfile;
sfile = fopen("score.txt","r");
fscanf(sfile,"%d",&highscore);
while (!feof(sfile))
    {
    printf("%d ",highscore);
    fscanf(sfile,"%d",&highscore);
    }
fclose(sfile);
    h:
    home(highscore);
    choice=toupper(getch());
    if (choice == 'A')
    {
        about();
        getch();
        goto h;
    }
    else if (choice == 'B')
    {
        rule();
        getch();
        goto h;
    }
    else if (choice == 'C')
    {
      goto game;
    }
    else if (choice == 'D')
    {
        return 0;
    }


    game:
    system("cls");
    printf("Press any key to continue!!");
    getch();
    system("cls");
    W = rand()%9;
    switch(W)
    {
        case 0 :
            printf("\n\nClue : Seleksi Masuk perguruan tinggi");
            file = fopen("1.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;
            }
            break;
        case 1 :
            printf("\n\nClue : Kejaran Dika Tak Tercapai");
            file = fopen("2.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;
            }
            break;
        case 2 :
            printf("\n\nClue : institusi pembelajaran");
            file = fopen("3.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;
            }
            break;
        case 3:
            printf("\n\nClue : Tempat pengambilan asupan gizi");

            file = fopen("4.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;
            }
            break;
        case 4:
            printf("\n\nClue : Kandang kuda besi");

            file = fopen("5.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;

            }
            break;
        case 5:
            printf("\n\nClue : Pengganti kuda");

            file = fopen("6.txt", "r");
            if (file)
            {
               while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;
            }
            break;
        case 6:
            printf("\n\nClue : Kecerobohan");

            file = fopen("7.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;

            }
            break;
        case 7:
            printf("\n\nClue : Bensin manusia");

            file = fopen("8.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;

            }
            break;
        case 8:
            printf("\n\nClue : negara yang jangkauan pantai Terpanjang");

            file = fopen("9.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;

            }
            break;
        case 9:
            printf("\n\nClue : Negara populasi terbanyak");

            file = fopen("10.txt", "r");
            if (file)
            {
                while ((c = getc(file))!= EOF)
                {
                    word[o][i]=c;
                    i++;
                }
                fclose(file);
                i=0;

            }
            break;
    }
    scan(word,loc,flag,freq);
    blocks(loc,word,spot);
    score = input_check(loc,word,spot,freq);
    printf("Answer : %s",word);
    ascore[count] = score;
    getch();
    printf("\n______________________________");
    printf("\n\n\t\tWould you like to try again?");

    printf("\n\t\tY  yes\n\t\tN  no");
    ch=toupper(getch());
    if (ch == 'Y')
    {
        count++;
        system("cls");
        goto h;
    }
    else
    {z=count+1;
    printf("\n______________________________");
    for(i=0;i<z;i++)
    { int u=i+1;
      printf("\nPlsyer %d Score : %d",u,ascore[i]);
    }
    getch();
    }
if (score>highscore)
{
    printf("Highscore!!!....");
    FILE * pFile;
   pFile = fopen ("score.txt","w");
    fprintf (pFile, "%d\n",score);
   fclose (pFile);
}
    return 0;
}

void home(int highscore)
{
    system("cls");
    printf("\n\n\t\t---------------------------");
    printf("\n\t\tWELCOME TO THE HANGMAN GAME");
    printf("\n\t\t---------------------------\n\n");
    printf("Current Highscore : %d",highscore);
    printf("\n\nPLEASE CHOOSE WHAT WOULD YOU LIKE TO DO:");
    printf("\n[A]  About Us\n[B]  How to Play\n[C]  Start\n[D]  Exit");
}


